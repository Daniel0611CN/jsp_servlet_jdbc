create
    definer = root@localhost procedure crea_libros_paidos()
BEGIN
  declare var_codigo int;
  declare var_titulo varchar(40);
  declare var_codigoeditorial int;
  declare var_precio decimal(5,2);
  declare var_final int default 0;
  
 DECLARE cursor_libros CURSOR FOR SELECT l.codigo, l.titulo, l.codigoeditorial, l.precio
FROM libros as l JOIN editoriales as e ON l.codigoeditorial=e.codigo where e.nombre = 'Paidos';
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
    
  OPEN cursor_libros;
  bucle: LOOP
    FETCH cursor_libros into var_codigo, var_titulo, var_codigoeditorial, var_precio;
    IF var_final = 1 THEN
      LEAVE bucle;
    END IF;
		INSERT into libros_paidos values (var_codigo, var_titulo, var_codigoeditorial, var_precio);
    END LOOP bucle;
  CLOSE cursor_libros;
  END;

