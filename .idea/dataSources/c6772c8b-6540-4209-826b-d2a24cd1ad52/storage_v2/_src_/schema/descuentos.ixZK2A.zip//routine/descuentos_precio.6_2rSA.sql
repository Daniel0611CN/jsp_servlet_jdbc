create
    definer = root@localhost procedure descuentos_precio()
BEGIN
DECLARE var_clave INT;
DECLARE var_descuento DECIMAL(10, 2);
DECLARE var_final INTEGER DEFAULT 0;
DECLARE cursor_descuentos CURSOR FOR SELECT clave, descuento FROM descuentos_precio;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
OPEN cursor_descuentos;
bucle: LOOP
FETCH cursor_descuentos INTO var_clave, var_descuento;
IF var_final = 1 THEN
LEAVE bucle;
END IF;
UPDATE productos SET precio = precio * (1 - var_descuento/100) WHERE clave = var_clave;
END LOOP bucle;
CLOSE cursor_descuentos;
END;

