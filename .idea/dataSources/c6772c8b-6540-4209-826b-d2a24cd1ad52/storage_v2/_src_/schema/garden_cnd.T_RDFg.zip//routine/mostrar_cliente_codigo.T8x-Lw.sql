create
    definer = root@localhost procedure mostrar_cliente_codigo(IN codigo_cliente int)
BEGIN
    DECLARE cliente_encontrado INT;
    SELECT COUNT(*) INTO cliente_encontrado FROM cliente WHERE codigo_cliente = codigo_cliente;
    IF cliente_encontrado > 0 THEN
        SELECT * FROM cliente WHERE codigo_cliente = codigo_cliente;
    ELSE
        SELECT 'Cliente no encontrado.' AS mensaje;
    END IF;
END;

