create definer = root@localhost trigger trigger1
    after insert
    on producto
    for each row
BEGIN
	DECLARE informacion TEXT;
	SET informacion = 'texto';
    INSERT INTO Logs (info) VALUES (informacion);
END;

