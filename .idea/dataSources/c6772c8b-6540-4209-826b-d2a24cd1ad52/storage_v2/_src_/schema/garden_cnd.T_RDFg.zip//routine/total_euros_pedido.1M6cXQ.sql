create
    definer = root@localhost function total_euros_pedido(codigo int, limite decimal(10, 2)) returns decimal(10, 2)
    deterministic
BEGIN
    DECLARE total DECIMAL(10,2);
    DECLARE pedido_encontrado INT;
    SELECT COUNT(*) INTO pedido_encontrado FROM pedido WHERE codigo = codigo_pedido_cnd;
    IF pedido_encontrado > 0 THEN
        SELECT SUM(precio_unidad) INTO total FROM detalle_pedido WHERE codigo = codigo_pedido_cnd;
        IF total > limite THEN
            SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'El total supera el límite permitido.';
        END IF;
        RETURN total;
    ELSE
        RETURN 0;
    END IF;
END;

