create definer = root@localhost trigger trigger2
    before insert
    on producto
    for each row
BEGIN
    IF NEW.cantidad_en_stock > 1000 THEN
        SET NEW.cantidad_en_stock = 1000;
    ELSEIF NEW.cantidad_en_stock < 0 THEN
        SET NEW.cantidad_en_stock = 0;
    END IF;
END;

