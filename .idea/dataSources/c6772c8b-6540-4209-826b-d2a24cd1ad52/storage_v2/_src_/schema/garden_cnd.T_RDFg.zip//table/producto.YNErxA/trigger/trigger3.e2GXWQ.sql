create definer = root@localhost trigger trigger3
    before insert
    on producto
    for each row
BEGIN
    DECLARE precio_proveedor DECIMAL(10, 2);

    SELECT precio_proveedor INTO precio_proveedor FROM producto WHERE codigo_producto_cnd = NEW.codigo_producto_cnd;
    SET precio_proveedor = precio_proveedor * 1.25;
    IF NEW.precio_venta < precio_proveedor THEN
        SET NEW.precio_venta = precio_venta + precio_proveedor*(25/100);
    END IF;
END;

