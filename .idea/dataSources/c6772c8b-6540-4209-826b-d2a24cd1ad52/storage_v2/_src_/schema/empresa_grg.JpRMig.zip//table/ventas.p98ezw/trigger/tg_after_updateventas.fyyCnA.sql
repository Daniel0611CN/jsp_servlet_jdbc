create definer = root@localhost trigger tg_after_updateventas
    after update
    on ventas
    for each row
BEGIN
	DECLARE numero_ventas INT;
    DECLARE volumen_ventas DECIMAL(10,2);
    SET numero_ventas = (SELECT SUM(cantidad_prod) FROM ventas WHERE cod_prod=new.cod_prod);
    SET volumen_ventas = (numero_ventas)*(SELECT (precio) FROM productos WHERE codigo=new.cod_prod);
    UPDATE estadisticas_ventas SET num_ventas=numero_ventas, total_ventas=volumen_ventas WHERE producto=new.cod_prod;
END;

