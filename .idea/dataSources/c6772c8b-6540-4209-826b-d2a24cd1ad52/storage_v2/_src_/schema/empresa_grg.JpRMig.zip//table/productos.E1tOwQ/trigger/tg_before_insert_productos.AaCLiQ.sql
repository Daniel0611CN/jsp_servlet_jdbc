create definer = root@localhost trigger tg_before_insert_productos
    before insert
    on productos
    for each row
BEGIN
	IF (new.precio<0) THEN
		SET new.precio=0;
	END IF;
END;

