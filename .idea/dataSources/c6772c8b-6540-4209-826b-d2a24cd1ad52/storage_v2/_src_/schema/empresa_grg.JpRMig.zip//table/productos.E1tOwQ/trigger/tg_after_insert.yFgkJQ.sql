create definer = root@localhost trigger tg_after_insert
    after insert
    on productos
    for each row
BEGIN
	DECLARE contador_prod INT;
    SET contador_prod = (SELECT COUNT(*) FROM productos WHERE proveedor_codigo=new.proveedor_codigo);
    IF (contador_prod =1) THEN
		INSERT INTO total_proveedores VALUES (new.proveedor_codigo, contador_prod);
    ELSE
		UPDATE total_proveedores SET total_productos=contador_prod WHERE cod_prov=new.proveedor_codigo;
    END IF;
END;

