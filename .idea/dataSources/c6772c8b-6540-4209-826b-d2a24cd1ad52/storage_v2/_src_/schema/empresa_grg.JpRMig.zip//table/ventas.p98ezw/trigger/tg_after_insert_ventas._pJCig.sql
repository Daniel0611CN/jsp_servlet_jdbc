create definer = root@localhost trigger tg_after_insert_ventas
    after insert
    on ventas
    for each row
BEGIN
	DECLARE contador_ventas INT;
    DECLARE volumen_ventas DECIMAL(10,2);
    SET contador_ventas = (SELECT COUNT(*) FROM estadisticas_ventas WHERE producto=new.cod_prod);
    SET volumen_ventas = (new.cantidad_prod)*(SELECT (precio) FROM productos WHERE codigo=new.cod_prod);
    IF (contador_ventas =0) THEN
		INSERT INTO estadisticas_ventas VALUES (new.cod_prod, new.cantidad_prod, volumen_ventas);
    ELSE
		UPDATE estadisticas_ventas SET num_ventas=num_ventas+new.cantidad_prod, total_ventas=total_ventas+volumen_ventas WHERE producto=new.cod_prod;
    END IF;
END;

