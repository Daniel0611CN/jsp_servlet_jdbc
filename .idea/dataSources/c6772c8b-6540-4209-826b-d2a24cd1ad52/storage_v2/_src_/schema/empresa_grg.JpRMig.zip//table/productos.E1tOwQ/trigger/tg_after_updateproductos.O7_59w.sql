create definer = root@localhost trigger tg_after_updateproductos
    after update
    on productos
    for each row
BEGIN
	DECLARE contador_prod INT;
    DECLARE contador_prod_old INT;
    SET contador_prod = (SELECT COUNT(*) FROM productos WHERE proveedor_codigo=new.proveedor_codigo);
    SET contador_prod_old = (SELECT COUNT(*) FROM productos WHERE proveedor_codigo=old.proveedor_codigo);
    IF (old.proveedor_codigo!=new.proveedor_codigo) THEN
		UPDATE total_proveedores SET total_productos=contador_prod WHERE cod_prov=new.proveedor_codigo;
        UPDATE total_proveedores SET total_productos=contador_prod_old WHERE cod_prov=old.proveedor_codigo;
    END IF;
END;

