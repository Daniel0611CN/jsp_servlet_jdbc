create definer = root@localhost trigger tg_after_deleteauditoriaprod
    after delete
    on productos
    for each row
BEGIN
	INSERT INTO auditoria_productos VALUES (CURDATE(), CURRENT_TIME(), 'Eliminar producto', old.codigo);
END;

