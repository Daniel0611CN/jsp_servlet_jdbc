create definer = root@localhost trigger tg_after_updateauditoriaprod
    after update
    on productos
    for each row
BEGIN
	INSERT INTO auditoria_productos VALUES (CURDATE(), CURRENT_TIME(), 'Producto actualizado', new.codigo);
END;

