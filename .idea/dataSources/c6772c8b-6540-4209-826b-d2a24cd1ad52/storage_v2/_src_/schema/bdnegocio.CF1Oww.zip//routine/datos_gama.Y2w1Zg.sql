create
    definer = root@localhost procedure datos_gama()
BEGIN
	select gama, COUNT(*) as Cantidad, SUM(precio) AS precioTotal FROM producto GROUP BY gama HAVING gama = "Dormitorio";
END;

