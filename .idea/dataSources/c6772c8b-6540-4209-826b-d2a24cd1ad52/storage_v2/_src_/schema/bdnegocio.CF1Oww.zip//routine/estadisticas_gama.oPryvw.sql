create
    definer = root@localhost function estadisticas_gama(gama_parametro varchar(255), operacion varchar(3)) returns decimal(10, 2)
    deterministic
BEGIN
    DECLARE resultado DECIMAL(10,2);

    IF operacion = 'max' THEN
        select MAX(precio) into resultado from producto where gama = gama_parametro;
    ELSEIF operacion = 'avg' THEN
        select AVG(precio) into resultado from producto where gama = gama_parametro;
    ELSEIF operacion = 'min' THEN
        select MIN(precio) into resultado from producto where gama = gama_parametro;
    ELSE
        SET resultado = NULL;
    END IF;

    RETURN resultado;
END;

