create
    definer = root@localhost procedure listar_todos_productos()
BEGIN
    select * from producto;
END;

