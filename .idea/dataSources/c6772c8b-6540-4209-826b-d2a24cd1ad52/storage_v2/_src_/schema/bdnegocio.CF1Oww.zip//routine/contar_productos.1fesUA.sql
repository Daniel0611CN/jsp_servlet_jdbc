create
    definer = root@localhost function contar_productos(precio_apr decimal(10, 2)) returns int deterministic
BEGIN
    DECLARE contador INT;
	
    select COUNT(*) into contador from producto where precio >= precio_apr;
			
	RETURN contador;
END;

