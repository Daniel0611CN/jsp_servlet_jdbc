create
    definer = root@localhost procedure listar_productos_gama()
BEGIN
	select * from producto where gama = 'Comedor';
END;

