create
    definer = root@localhost procedure actualizar_precios()
BEGIN
DECLARE var_clave INT;
DECLARE var_nuevo_precio DECIMAL(10, 2);
DECLARE var_final INTEGER DEFAULT 0;
DECLARE cursor_precios CURSOR FOR SELECT clave, nuevo_precio FROM cambios_precio;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
OPEN cursor_precios;
bucle: LOOP
FETCH cursor_precios INTO var_clave, var_nuevo_precio;
IF var_final = 1 THEN
LEAVE bucle;
END IF;
UPDATE productos SET precio = var_nuevo_precio WHERE clave = var_clave;
END LOOP bucle;
CLOSE cursor_precios;
END;

