create
    definer = root@localhost procedure calcular_total_ventas_por_cliente()
BEGIN
DECLARE var_final INT DEFAULT 0;
DECLARE cliente_id_var INT;
DECLARE total_ventas DECIMAL(10, 2);
-- Declaración del cursor para recorrer las ventas por cliente
DECLARE ventas_cursor CURSOR FOR SELECT DISTINCT cliente_id FROM ventas;
-- Manejador para finalización del cursor
DECLARE CONTINUE HANDLER FOR NOT FOUND SET var_final = 1;
-- Abre el cursor
OPEN ventas_cursor;
read_loop: LOOP
FETCH ventas_cursor INTO cliente_id_var;
IF var_final = 1 THEN
LEAVE read_loop;
END IF;
-- Calcula el total de ventas para el cliente actual
SELECT SUM(monto) INTO total_ventas FROM ventas WHERE cliente_id = cliente_id_var;
-- Inserta el total de ventas en la tabla total_ventas_por_cliente
INSERT INTO total_ventas_por_cliente (cliente_id, total) VALUES (cliente_id_var,
total_ventas);
END LOOP;

-- Cierra el cursor
CLOSE ventas_cursor;
END;

